<?php
 if(isset($_POST['submit'])){	
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$msg = $_POST['msg'];
		$from = "Avellinaa Esthetics <info@avellinaaesthetics.com>";
	$to = "seoprocessusa@gmail.com,";
	$subject = " Lead ( Avellinaa Esthetics )";
$message = '<html><body>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . $name . "</td></tr>";
$message .= "<tr><td><strong>Email:</strong> </td><td>" . $email. "</td></tr>";
$message .= "<tr><td><strong>Phone Number:</strong> </td><td>" . $phone . "</td></tr>";
$message .= "<tr><td><strong>Message:</strong> </td><td>" . $msg. "</td></tr>";

$message .= '</body></html>';


$headers = 'MIME-Version: 1.0' . "\r\n";
            $headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	
$headers .= 'From: '.$name.'<'.$email.'>' . "\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 

	$data= $retval= mail($to,$subject,$message,$headers);
	if($data){
		header('location:https://www.avellinaaesthetics.com/thank-you');
	}
 }	
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Our Passion is Beautiful Skin - Avellina Aesthetics</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link href="images/favicon.png" type="images/x-icon" rel="shortcut icon">
     <!-- All css files are included here. -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/shortcode/shortcodes.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="css/icofont.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
<!--    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/plugins/animate.css">-->
    <link rel="stylesheet" href="css/plugins/animated-headlines.css">
<!--    <link rel="stylesheet" href="css/plugins/jquery.mb.YTPlayer.min.css">
   <link rel="stylesheet" href="css/plugins/meanmenu.min.css">-->  
  <!-- <link rel="stylesheet" href="css/plugins/owl.carousel.css">-->
<!--    <link rel="stylesheet" href="css/plugins/owl.theme.css">
-->
<link rel="stylesheet" href="css/plugins/nivo-slider.css">
    <link rel="stylesheet" href="css/plugins/jquery-ui.min.css">
  <!--  <link rel="stylesheet" href="css/plugins/fakeLoader.css">-->
    <link rel="stylesheet" href="css/plugins/bootstrap-select.css">
   <!-- <link rel="stylesheet" href="css/plugins/owl.transitions.css">
    <link rel="stylesheet" href="css/plugins/magnific-popup.css">-->
    <link rel="stylesheet" href="css/shortcode/default.css">
       <style>
        textarea{
    background: #fff;
    box-shadow: 0px 0px 2px #0000008c;
    border: none;
    border-radius: 3px;
}
textarea:focus {
    border: 0px;
    outline: 0;
    background: #fff !important;
}
</style>
    <!-- customizer style css -->
<!--    <link rel="stylesheet" href="css/style-customizer.css">
-->    <!-- Modernizr JS -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

</head>
<body>
     
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->  
    <!--Preloader start-->
    <!--Preloader end-->
   <!--Header section start-->
   <div class="wrapper">
        <header class="header">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-6">
                            <div class="logo">
                    <a href="https://www.avellinaaesthetics.com/"><img src="images/120 x 88 px.png" alt=""></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-xs-6">
                            <div class="mgea-full-width">
                                <div class="header-menu">
                                    <nav>
                                        <ul>
                                            
                                              <li> <a href="tel:(215) 722-6022">Call us : &nbsp;(215) 722-6022</a></li>
                                              
                                              
                                         
                                        </ul>
                                    </nav>
                                </div>
                            </div>
				            </div>
						<div class="col-md-3 hidden-sm hidden-xs">
							<div class="social-list hidden-xs">
								
                                    <a href="https://www.facebook.com/AvellinaAesthetics/"><i class="fa fa-facebook"></i></a>
                                    <a href="https://www.instagram.com/avellina_aesthetics/"><i class="fa fa-instagram"></i></a>
                                     <a href="https://www.yelp.com/biz/avellina-aesthetics-philadelphia"><i class="fa fa-yelp"></i></a>
                                    
							</div>
						</div>
            	
                    </div>
                </div>
				
            </div>
            
        </header>
        <!--Header section end-->
        <!--slider section start-->
        <div class="slider-area">
        <div class="slider-container overlay home-2">
            <!-- Slider Image -->
            <div id="mainSlider" class="nivoSlider slider-image">
                <img src="images/11.jpg" alt="" title="#htmlcaption1"/>
               
            </div>
            <!-- Slider Caption 1 -->
            <div id="htmlcaption1" class="nivo-html-caption slider-caption-1">
               <div class="display-table">
                    <div class="display-tablecell">
                        <div class="container ">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="slide1-text">
                                        <div class="middle-text">
                                            <div class="title-1 wow fadeUp" data-wow-duration="0.9s" data-wow-delay="0s">
                                            
                                            </div>	
                                            <div class="title-2 wow fadeUp" data-wow-duration="1.9s" data-wow-delay="0.1s">
                                                <h1><span>OUR PASSION IS</span>  BEAUTIFUL</br> SKIN</h1>
                                            </div>	
                                            <div class="desc wow fadeUp" data-wow-duration="1.2s" data-wow-delay="0.2s">
                                                <p>Avellina Aesthetics is a premier skin rejuvenation clinic in northeast Philadelphia<br>
specializing in medical weight loss, filler, mesotherapy and PDO threads.</p>
                                            </div>
                                            <div class="desktop-hide contact-us wow fadeUp" data-wow-duration="1.3s" data-wow-delay=".5s">
                            <a href="tel:(215) 722-6022">Call Now ! (215) 722-6022</a>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>	
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!--Find home area start-->
            <div class="finde-home-postion">
                <div class="container">
                    <div class="find-home-box postion">
                        <div class="find-home-box-inner">
                        <div class="find-home-title">
                            <h3>MAKE AN APPOINTMENT</h3>
                        </div>
                            <form method="post">
                                <div class="find-home-cagtegory">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item custom-select ">                  
                                                <input type="text" name="name" class="" placeholder="Name" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item">
                                                <input type="mail" name="email" placeholder="Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item ">
                                                <input type="tel" name="phone" placeholder="Phone no." required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item">                  
                                                 <input type="textarea" name="msg" placeholder="Your Message" required>
                                            </div> 
                                        </div>
                                        

                                    <div class="find-home-bottom">
                                        <div class="col-md-12 col-sm-6 col-xs-12">
                                            <br/>
                                            <div class="find-home-item">
                                                       <input type="submit" name="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--Find home area end-->
    </div>
        <!--slider section end-->
   
        <!--Welcome Haven section-->
        <div class="welcome-haven bg-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 fadeInLeft wow welcome-pd" data-wow-delay="0.2s">
					<div class="welcome-content">
					    <h3 class="title-1">SERVICES</h3>

                        </div>
                        <div class="welcome-services">
                            <div class="row">
                               
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/icon/Fillers.png" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Fillers</h6>
                                            <p>A popular cosmetic enhancement, filler restores the fullness and volume that is telltale of youthful skin. This minimally invasive treatment, when in the hands of an expert, leaves skin looking rejuvenated, more youthful, and best of all—still looking natural.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/icon/1.png" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Medical Weight Loss </h6>
                                            <p>Having the supervision of a medical professional is the missing link to help you achieve your weight loss goals. In your personalized program, a physician, dietician, and/or exercise trainer will be your allies to help you stay consistent and get the results you deserve.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                 <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/icon/mesotherapy.png" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Mesotherapy</h6>
                                            <p>This treatment is a skin rejuvenation procedure that uses tiny injections to flood the skin with vitamins, minerals, plant extracts, and even hormones. The result is skin with more bounce, smoothness, and glow.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                 <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                      <div class="services-img">
                                            <img src="images/icon/PDO Thread Lift.png" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>PDO Thread Lift</h6>
                                            <p>A technique that uses dissolvable sutures for skin anti-aging and rejuvenation. This popular and safe procedure helps to lift sagging skin—and it’s also a more affordable procedure compared to invasive facelift surgeries.</p>
                                        </div>
                                    </div>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Welcome Haven section end-->

        <!--Download apps section start-->
        
     
<section id="ab8" class="about-head p-70" style="padding-bottom: 0;">
    <div class="container">
		<div class="row">
			<div class="col-md-7 p-40">	
			<div class="welcome-title">
		
                            <h3 class="title-1">RESULTS THAT LOOK NATURAL</h3>
                        </div>
                        
                        <p>Avellina Aesthetics is a premier skin rejuvenation clinic in northeast Philadelphia specializing in Weight loss, Fillers, Mesotherapy and Threads. Here at Avellina Aesthetics we practice non-surgical, natural looking results utilizing latest innovations and time-proven techniques. We have a passion for skin care - only using the best quality products and state of the art technique.</p>

				<p> Services offered include Weight loss, Fillers, Mesotherapy and Threads. All injections are performed by a doctor certified in aesthetic medicine, Dr. Violetta Berdichevskaya has been practicing Internal Medicine for over 20 years - so you know you’re in good hands. </p><p>Rejuvenate and renew your skin bringing youth and vitality back into your life. Avellina Aesthetics is a premier skin rejuvenation clinic in northeast Philadelphia.</p>
			</div>
			<div class="col-md-5">
					<div class="video">
				    <img src="images/IMG_8713.jpg">
				    
				</div>
			</div>
				</div>
			<div class="col-md-12" style="padding-left:0;padding-top:20px">
			    
	
	</div>
</section>

		
        <!--Feature property section-->
    
<section class="call-to-action-section">
    	<div class="container">
        	<div class="row clearfix">
            	
                <!--Content Column-->
                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                	<div class="inner-column">
                    	<h2 class="text-cente"> Contact Us For a Complimentary Skin Consultation With the Doctor.</h2>
                        <!--<div class="text">Talk to us! We promise we will provide best services!</div>-->
                    </div>
                </div>
                
                <!--Button Column-->
                <div class="btn-column col-md-3 col-sm-12 col-xs-12">
                	<div class="inner-column">
                     <div class="text"><span>Call Now! <a href="tel:(215) 722-6022">(215) 722-6022</a></span></div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
        
        
        
        <section class="form-sec p-70">
            <div class="container">
                <div class="row">
                        <form method="post">
                                <div class="find-home-cagtegory form-footer">
                                    <h3>MAKE AN APPOINTMENT</h3>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item custom-select ">                  
                                                <input id="input-footer" type="text" name="name" class="" placeholder="Name" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item">
                                                <input  id="input-footer" type="mail" name="email" placeholder="Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item ">
                                                <input  id="input-footer" type="tel" name="phone" placeholder="Phone no." required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-6 col-xs-12">
                                            <div class="find-home-item">                  
                                                

                                                    </textarea>
 <textarea placeholder="Your Message" name="msg" maxlength="1000" cols="25" rows="6"></textarea>
                                            </div> 
                                        </div>
                                        

                                    <div class="find-home-bottom">
                                        <div class="col-md-4 col-md-offset-4 col-sm-6 col-xs-12">
                                            <br/>
                                            <div class="find-home-item">
                            <input id="submit-input" type="submit" name="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                </div>
                
            </div>
            
        </section>
        <footer class="footer wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="map-area">
                                <div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3568.4712960670827!2d-81.94558998548685!3d26.569247681188855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88db40a81b08db05%3A0x67a9d37a4b8069d2!2s4423+Del+Prado+Blvd+S%2C+Cape+Coral%2C+FL+33904%2C+USA!5e0!3m2!1sen!2sin!4v1557273351925!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                                <!--Footer desc start-->
                                <div class="footer-desc">
                                    <div class="singe-footer-newsletter">
                                        <div class="footer-logo">
                                            <div class="f-logo">
                                <a href="#"><img src="images/logo.png"></a>
                                            </div>
                                        </div>
                                        <div class="newsletter">
                                            <p></p>
                                                                                   </div>
                                    </div>
                                    <div class="single-footer-contact">
                                        <div class="contact-head">
                                            <h2>CONTACT US</h2>
                                            <p>Call Today – We are here to help. </p>
                                        </div>
                                        <div class="f-contact-details">
                                            <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-1.png" alt="">
                                                </div>
                                                <div class="contact-text">
                                                    <p>4423 Del Prado Blvd,</p>
                                                  <p> Cape Coral, FL 33904 </p>
                                                </div>
                                            </div>
                                         
                                                <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-2.png" alt="">
                                                </div>
                                                
                                                
                                                  <div class="contact-text">
                                                    <p>Telephone : <a href="tel:(239) 549-6689">(239) 549-6689</a></p>
                                                </div>
                                            </div>
                                            
                                            <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-3.png" alt="">
                                                </div>
                                                <div class="contact-text">
                                                    <p>Email : <a href="mailto:Berkelaw@Yahoo.Com">Berkelaw@Yahoo.Com</a></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Footer desc end-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Footer bottom start-->
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                           <p>Copyright © 2022 Avellina Aesthetics All Rights Reserved</p>
                        </div>
                       
                    </div>
                </div>
            </div>
            <!--Footer bottom end-->
         </footer>
    <!-- Placed js at the end of the document so the pages load faster -->
    </div>
        <!--=================================
     style-customizer start  -->

   
    
    
    
    <!-- Map js code here -->
<!--	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAj9b_nyz33KEaocu6ZOXRgqwwUZkDVEAw"></script>
    <script src="js/map.js"></script>-->

    <!-- All jquery file included here -->
    <script src="js/vendor/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nivo.slider.pack.js"></script>
   <!-- <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>-->
    <script src="js/ajax-mail.js"></script>
<!--    <script src="js/owl.carousel.min.js"></script>
-->    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/style-customizer.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>

</html>