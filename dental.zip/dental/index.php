<?php
 if(isset($_POST['submit'])){   
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $msg = $_POST['msg'];
        $from = "philadelphia mills dental <office@philamillsdental.com>";
    $to = "seoprocessusa@gmail.com,";
    $subject = " Lead ( philadelphia mills dental )";
$message = '<html><body>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . $name . "</td></tr>";
$message .= "<tr><td><strong>Email:</strong> </td><td>" . $email. "</td></tr>";
$message .= "<tr><td><strong>Phone Number:</strong> </td><td>" . $phone . "</td></tr>";
$message .= "<tr><td><strong>Message:</strong> </td><td>" . $msg. "</td></tr>";

$message .= '</body></html>';


$headers = 'MIME-Version: 1.0' . "\r\n";
            $headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    
$headers .= 'From: '.$name.'<'.$email.'>' . "\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 

    $data= $retval= mail($to,$subject,$message,$headers);
    if($data){
        header('location:https://www.philamillsdental.com/');
    }
 }  
?>

<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Philadelphia Mills Dental Center</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link href="images/official-logo2.png" type="images/x-icon" rel="shortcut icon">
     <!-- All css files are included here. -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/shortcode/shortcodes.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="stylesheet" href="css/icofont.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
<!--    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/plugins/animate.css">-->
    <link rel="stylesheet" href="css/plugins/animated-headlines.css">
<!--    <link rel="stylesheet" href="css/plugins/jquery.mb.YTPlayer.min.css">
   <link rel="stylesheet" href="css/plugins/meanmenu.min.css">-->  
  <!-- <link rel="stylesheet" href="css/plugins/owl.carousel.css">-->
<!--    <link rel="stylesheet" href="css/plugins/owl.theme.css">
-->
<link rel="stylesheet" href="css/plugins/nivo-slider.css">
    <link rel="stylesheet" href="css/plugins/jquery-ui.min.css">
  <!--  <link rel="stylesheet" href="css/plugins/fakeLoader.css">-->
    <link rel="stylesheet" href="css/plugins/bootstrap-select.css">
   <!-- <link rel="stylesheet" href="css/plugins/owl.transitions.css">
    <link rel="stylesheet" href="css/plugins/magnific-popup.css">-->
    <link rel="stylesheet" href="css/shortcode/default.css">
       <style>
        textarea{
    background: #fff;
    box-shadow: 0px 0px 2px #0000008c;
    border: none;
    border-radius: 3px;
}
textarea:focus {
    border: 0px;
    outline: 0;
    background: #fff !important;
}
</style>
    <!-- customizer style css -->
<!--    <link rel="stylesheet" href="css/style-customizer.css">
-->    <!-- Modernizr JS -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

</head>
<body>
     
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->  
    <!--Preloader start-->
    <!--Preloader end-->
   <!--Header section start-->
   <div class="wrapper">
        <header class="header">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-6">
                            <div class="logo">
                    <a href="https://www.philamillsdental.com/"><img src="images/official-logo2.png" alt="" height="88" width="200"></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-xs-6">
                            <div class="mgea-full-width">
                                <div class="header-menu">
                                    <nav>
                                        <ul>
                                            
                                              <li> <a href="tel:(215) 632-7700"><i class="fa fa-phone"></i> &nbsp;(215) 632-7700</a></li>
                                              
                                              
                                         
                                        </ul>
                                    </nav>
                                </div>
                            </div>
				            </div>
						<div class="col-md-3 hidden-sm hidden-xs">
							<div class="social-list hidden-xs">
								
                                    <a href="https://www.facebook.com/philamillsdental"><i class="fa fa-facebook"></i></a>
                                    <!--<a href="https://www.instagram.com/avellina_aesthetics/"><i class="fa fa-instagram"></i></a>
                                     <a href="https://www.yelp.com/biz/avellina-aesthetics-philadelphia"><i class="fa fa-yelp"></i></a>-->
                                    
							</div>
						</div>
            	
                    </div>
                </div>
				
            </div>
            
        </header>
        <!--Header section end-->
        <!--slider section start-->
        <div class="slider-area">
        <div class="slider-container overlay home-2">
            <!-- Slider Image -->
            <div id="mainSlider" class="nivoSlider slider-image">
                <img src="images/0-overlay.jpg" alt="" title="#htmlcaption1"/>
               
            </div>
            <!-- Slider Caption 1 -->
            <div id="htmlcaption1" class="nivo-html-caption slider-caption-1">
               <div class="display-table">
                    <div class="display-tablecell">
                        <div class="container ">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="slide1-text">
                                        <div class="middle-text">
                                            <div class="title-1 wow fadeUp" data-wow-duration="0.9s" data-wow-delay="0s">
                                            
                                            </div>	
                                            <div class="title-2 wow fadeUp" data-wow-duration="1.9s" data-wow-delay="0.1s">
                                                <h1><span>Philadelphia Mills</br> Dental Center</h1>
                                            </div>	
                                            <div class="desc wow fadeUp" data-wow-duration="1.2s" data-wow-delay="0.2s">
                                                <p>Philadelphia Mills Dental Center proudly</br>opened its doors in September
2018 and<br> is now accepting new patients</p>
                                            </div>
                                            <div class="desktop-hide contact-us wow fadeUp" data-wow-duration="1.3s" data-wow-delay=".5s">
                            <a href="tel:(215) 632-7700">Call Now ! (215) 632-7700</a>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>	
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!--Find home area start-->
            <div class="finde-home-postion">
                <div class="container">
                    <div class="find-home-box postion">
                        <div class="find-home-box-inner">
                        <div class="find-home-title">
                            <h3>MAKE AN APPOINTMENT</h3>
                        </div>
                            <form method="post">
                                <div class="find-home-cagtegory">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item custom-select ">                  
                                                <input type="text" name="name" class="" placeholder="Name" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item">
                                                <input type="mail" name="email" placeholder="Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item ">
                                                <input type="tel" name="phone" placeholder="Phone no." required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="find-home-item">                  
                                                 <input type="textarea" name="msg" placeholder="Your Message" required>
                                            </div> 
                                        </div>
                                        

                                    <div class="find-home-bottom">
                                        <div class="col-md-12 col-sm-6 col-xs-12">
                                            <br/>
                                            <div class="find-home-item">
                                                       <input type="submit" name="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--Find home area end-->
    </div>
        <!--slider section end-->
   
        <!--Welcome Haven section-->
        <div class="welcome-haven bg-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 fadeInLeft wow welcome-pd" data-wow-delay="0.2s">
					<div class="welcome-content">
					    <h3 class="title-1">SERVICES</h3>

                        </div>
                        <div class="welcome-services">
                            <div class="row">
                               
                                <div class="col-md-4 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/Preventive.jpg" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Preventive</h6>
                                            <p> Keep track of your dental health. Ignoring in the short term can lead to big problems in the long term. You may end up needing a crown or even a root canal because of decay or damage. </p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/Cosmetic.jpg" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Cosmetic</h6>
                                            <p> Improving the look of your smile can also improve your daily life in ways you wouldn’t think. A more pleasing smile can enhance your personal and professional interactions. </p>
                                        </div>
                                    </div>
                                </div>
                                
                                 <div class="col-md-4 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                        <div class="services-img">
                                            <img src="images/Restorative.jpg" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Restorative</h6>
                                            <p> Our team provides advanced restorative treatments to help you get strong teeth and a healthy smile once again. </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-12 ">
                                </div>
                                 <div class="col-md-4 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                      <div class="services-img">
                                            <img src="images/Endodontic.jpg" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Endodontic</h6>
                                            <p> Our services include managing pain using cutting-edge teeth-saving root canal techniques. </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-3 col-xs-12 ">
                                    <div class="w-single-services">
                                      <div class="services-img">
                                            <img src="images/Oral Surgery.jpg" alt="">
                                        </div>
                                        <div class="services-desc">
                                            <h6>Oral Surgery</h6>
                                            <p> We perform Tooth Extractions, including wisdom teeth; Dental Implant Surgey; as well as Bone Graft Surgery. </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2 col-sm-3 col-xs-12 ">
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Welcome Haven section end-->







        <!--Welcome Haven section-->
        <div class="welcomes-haven bg-2">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 fadeInLeft wow welcome-pd" data-wow-delay="0.2s">
                        <div class="video image-specials">
                            <img src="images/SP-Dental.png" class="img-responsive rotatingimg center-block">
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Welcome Haven section end-->
        


<section style="margin-top: 50px;">
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <img class="img-responsive" src="images/banner-special-new.png" alt="" width="100%" height="380" />
            
        </div>
    </div>
    </section>





        <!--Feature property section

    
<section class="call-to-action-section new" style="margin-top: 20px;">

        <div class="container">
            <div class="row clearfix">
<div class="content-column col-md-12 col-sm-12 col-xs-12"></div>-->
                
                <!--Content Column-->
                <!--<div class="content-column col-md-6 col-sm-12 col-xs-12">-->
                <!--    <div class="inner-column" style="margin-top: -20px;"> -->
                <!--        <h2 class="text-center" style="font-size: 35px; color: #fff; font-style: italic; font-family: 'Alex Brush', cursive; text-shadow: 2px 2px #ff0000;"> We are currently extending a special offer for our new patients: Check up, prophylaxis cleaning and x-rays for <span class="dollor-highlight"><span class="dollor">$</span>130</span> !</h2>-->
                        <!--<div class="text">Talk to us! We promise we will provide best services!</div>-->

                <!--        <h2 class="text-center" style="font-size: 28px !important; margin-top: 30px; font-family: 'Alex Brush', cursive; font-style: italic; text-shadow: 2px 2px #ff0000;"> Hola! Hablamos Español! Ofrecemos un especial para nuevos pacientes: <span class="dollor-highlight"><span class="dollor">$</span>130</span> para examen, profilaxis y radiografías. Llámanos para programar su pròxima visita dental.</h2>-->

                        
                <!--    </div>-->
                <!--</div>
            
                
            </div>-->
   
                <!--<div class="btn-column col-md-12 col-sm-12 col-xs-12" style="margin-top: 15px; margin-bottom: -60px;">-->
                <!--    <div class="inner-column">-->
                <!--     <p class="text-center back-special-design" style="color: red; font-size: 17px; font-family: 'Alex Brush', cursive;">* <b>SPECIAL OFFER</b> Offer Good Through September 1st, 2022. Offer may not be combined with any other offer or promotion.</p>-->
                <!--    </div>-->
                <!--</div>
                
        </div>
    </section>-->

        <!--Download apps section start-->
        
     
<section id="ab8" class="about-head s-2 p-70" style="padding-bottom: 0;">
    <div class="overlay-text-content"></div>
    <div class="container">
		<div class="row">
			<div class="col-md-7 p-40">	
			<div class="welcome-title">
		
                            <h3 class="title-1" style="color: #000 !important;">Philadelphia Mills Dental Center</h3>
                        </div>

                        <p class="why-content-style">Philadelphia Mills Dental Center proudly opened its doors in September 2018 and is now accepting new patients. The dental center offers an extraordinary staff who will go far to make your smile look its best. Our state-of-the-art digital dental equipment is industry-leading, providing our patients the latest technology in oral care.</p>
                        
                        <p class="why-content-style">We would love the opportunity to show you what truly exceptional dental care is all about. Our goal is to provide our patients with care that lasts a lifetime, and we are always very happy to have new patients become part of our family.</p>

				<p class="why-content-style">Our entire team has received special training in providing comfortable, quality dental care and we love what we do! We welcome the opportunity to provide your routine care, and we strive to treat emergencies the same day.</p>
			</div>
			<div class="col-md-5">
					<div class="video">
				    <img src="images/philamills.jpg">
				    
				</div>
			</div>
				</div>
			<div class="col-md-12" style="padding-left:0;padding-top:60px">
			    
	
	</div>
</section>

		
        <!--Feature property section-->
    
<section class="call-to-action-section">
    	<div class="container">
        	<div class="row clearfix">
            	
                <!--Content Column-->
                <div class="content-column col-md-7 col-sm-12 col-xs-12">
                	<div class="inner-column">
                    	<h2 class="text-cente"> PHILADELPHIA MILLS DENTAL CENTER</h2>
                        <!--<div class="text">Talk to us! We promise we will provide best services!</div>-->
                    </div>
                </div>
                
                <!--Button Column-->
                <div class="btn-column col-md-5 col-sm-12 col-xs-12">
                	<div class="inner-column">
                     <div class="text"><span>Call Now! <a href="tel:(215) 632-7700">(215) 632-7700</a></span></div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
        
        
        
        <section class="form-sec p-70">
            <div class="container">
                <div class="row">
                        <form method="post">
                                <div class="find-home-cagtegory form-footer">
                                    <h3>MAKE AN APPOINTMENT</h3>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item custom-select ">                  
                                                <input id="input-footer" type="text" name="name" class="" placeholder="Name" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item">
                                                <input  id="input-footer" type="mail" name="email" placeholder="Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="find-home-item ">
                                                <input  id="input-footer" type="tel" name="phone" placeholder="Phone no." required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-6 col-xs-12">
                                            <div class="find-home-item">                  
                                                

                                                    </textarea>
 <textarea placeholder="Your Message" name="msg" maxlength="1000" cols="25" rows="6"></textarea>
                                            </div> 
                                        </div>
                                        

                                    <div class="find-home-bottom">
                                        <div class="col-md-4 col-md-offset-4 col-sm-6 col-xs-12">
                                            <br/>
                                            <div class="find-home-item">
                            <input id="submit-input" type="submit" name="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                </div>
                
            </div>
            
        </section>
        <footer class="footer wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="map-area">
                                <div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3568.4712960670827!2d-81.94558998548685!3d26.569247681188855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88db40a81b08db05%3A0x67a9d37a4b8069d2!2s4423+Del+Prado+Blvd+S%2C+Cape+Coral%2C+FL+33904%2C+USA!5e0!3m2!1sen!2sin!4v1557273351925!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                                <!--Footer desc start-->
                                <div class="footer-desc">
                                    <div class="singe-footer-newsletter">
                                        <div class="footer-logo">
                                            <div class="f-logo">
                                <a href="#"><img src="images/logo.png"></a>
                                            </div>
                                        </div>
                                        <div class="newsletter">
                                            <p></p>
                                                                                   </div>
                                    </div>
                                    <div class="single-footer-contact">
                                        <div class="contact-head">
                                            <h2>CONTACT US</h2>
                                            <p>Call Today – We are here to help. </p>
                                        </div>
                                        <div class="f-contact-details">
                                            <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-1.png" alt="">
                                                </div>
                                                <div class="contact-text">
                                                    <p>4423 Del Prado Blvd,</p>
                                                  <p> Cape Coral, FL 33904 </p>
                                                </div>
                                            </div>
                                         
                                                <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-2.png" alt="">
                                                </div>
                                                
                                                
                                                  <div class="contact-text">
                                                    <p>Telephone : <a href="tel:(239) 549-6689">(239) 549-6689</a></p>
                                                </div>
                                            </div>
                                            
                                            <div class="single-contact-list">
                                                <div class="contact-icon">
                                                    <img src="img/icon/c-3.png" alt="">
                                                </div>
                                                <div class="contact-text">
                                                    <p>Email : <a href="mailto:Berkelaw@Yahoo.Com">Berkelaw@Yahoo.Com</a></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Footer desc end-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Footer bottom start-->
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                           <p>Copyright © 2022 Philadelphia Mills Dental Center All Rights Reserved</p>
                        </div>
                       
                    </div>
                </div>
            </div>
            <!--Footer bottom end-->
         </footer>
    <!-- Placed js at the end of the document so the pages load faster -->
    </div>
        <!--=================================
     style-customizer start  -->

   
    
    
    
    <!-- Map js code here -->
<!--	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAj9b_nyz33KEaocu6ZOXRgqwwUZkDVEAw"></script>
    <script src="js/map.js"></script>-->

    <!-- All jquery file included here -->
    <script src="js/vendor/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nivo.slider.pack.js"></script>
   <!-- <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>-->
    <script src="js/ajax-mail.js"></script>
<!--    <script src="js/owl.carousel.min.js"></script>
-->    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/style-customizer.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>

</html>